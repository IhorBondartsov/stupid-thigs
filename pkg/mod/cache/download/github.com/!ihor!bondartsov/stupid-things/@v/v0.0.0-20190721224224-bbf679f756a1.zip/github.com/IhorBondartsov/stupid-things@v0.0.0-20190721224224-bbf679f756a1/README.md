# stupid-thnigs
